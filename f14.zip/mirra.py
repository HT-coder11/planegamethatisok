# The Mirror
from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController
from ursina.audio import Audio
from math import ceil
import random

app = Ursina()
Sky(color = color.azure)

window.title = "burger mnirror"

window.borderless = False
window.fullscreen = False
clouds = []

for i in range(150):
    cloud = Entity(
        model="minecraftclouds.glb",
        scale=random.uniform(300, 400),
        collider="box",

        position=(
            random.uniform(-7000, 7000),  
            random.uniform(100, 600),   
            random.uniform(-7000, 7000) 
        ),

        color=color.rgba(
            255, 255, 255,
            random.randint(100, 170)
        )
    )

    clouds.append(cloud)



player = FirstPersonController(position=(0,300,0) )
player.gravity = 0
player.speed = 180

speed = 15
turn_speed = 50
enemy_speed = 140
time_remaining = 30
game_over = False
missile_cooldown = 3
missiles = []
dodge_message_time = 0
score = 0
clouds_rewarded = set()

enemy = Entity(
    position=player.position - player.forward * 800,
)
enemy_model = Entity(
    parent=enemy,
    model="f14.glb",
    scale=0.6,
    rotation_x=180,
    rotation_z=180,
    color=color.red,
)

timer_text = Text(
    parent=camera.ui,
    text="TIME TO ESCAPE: 30",
    position=(-0.85, 0.45),
    scale=2,
    background=True,
)
status_text = Text(
    parent=camera.ui,
    text="",
    origin=(0, 0),
    scale=3,
    enabled=False,
)
missile_text = Text(
    parent=camera.ui,
    text="",
    position=(-0.85, 0.38),
    scale=1.5,
    color=color.orange,
)
score_text = Text(
    parent=camera.ui,
    text="SCORE: 000",
    position=(0.55, 0.45),
    scale=1.5,
    background=True,
)
reward_text = Text(
    parent=camera.ui,
    text="",
    position=(-0.85, 0.30),
    scale=1.5,
    color=color.yellow,
)
reward_message_time = 0

def update():
    global time_remaining, game_over, missile_cooldown, dodge_message_time
    global score, reward_message_time

    if game_over:
        return

    score += 10 * time.dt
    score_text.text = f"SCORE: {int(score)}"
    previous_position = Vec3(player.position)

    if held_keys["w"]:
        player.position += player.forward * speed * time.dt

    if held_keys["s"]:
        player.position -= player.forward * speed * time.dt


    turbo = held_keys["shift"]
    if turbo:
        player.speed = 300
    else:
        player.speed = 180

    if player.intersects().hit:
        player.position = previous_position

    for cloud_index, cloud in enumerate(clouds):
        if (
            cloud_index not in clouds_rewarded
            and distance(player.position, cloud.position) < cloud.scale * 1.5
        ):
            clouds_rewarded.add(cloud_index)
            score += 50
            score_text.text = f"SCORE: {int(score)}"
            reward_text.text = "CLOUD SKIM +50"
            reward_message_time = 1.5

    missile_cooldown -= time.dt
    if missile_cooldown <= 0:
        target_position = Vec3(player.position)
        launch_direction = target_position - enemy.position
        if launch_direction.length() > 0:
            launch_direction = launch_direction.normalized()
            missile = Entity(
                model="sphere",
                color=color.red,
                scale=12,
                position=enemy.position + launch_direction * 35,
            )
            missiles.append((missile, launch_direction))
            missile_text.text = "MISSILE! BOOST when it gets close!"
        missile_cooldown = 5

    for missile, missile_direction in missiles[:]:
        missile.position += missile_direction * 260 * time.dt
        missile_distance = distance(player.position, missile.position)
        if turbo and missile_distance < 100:
            destroy(missile)
            missiles.remove((missile, missile_direction))
            missile_text.text = "DODGED!"
            dodge_message_time = 1
            score += 100
            score_text.text = f"SCORE: {int(score)}"
            reward_text.text = "BOOST DODGE +100"
            reward_message_time = 1.5
        elif missile_distance < 20:
            status_text.text = f"HIT BY A MISSILE!\nSCORE: {int(score)}"
            status_text.enabled = True
            player.speed = 0
            game_over = True
            return
        elif distance(enemy.position, missile.position) > 1500:
            destroy(missile)
            missiles.remove((missile, missile_direction))

    if dodge_message_time > 0:
        dodge_message_time -= time.dt
        if dodge_message_time <= 0:
            missile_text.text = ""

    if reward_message_time > 0:
        reward_message_time -= time.dt
        if reward_message_time <= 0:
            reward_text.text = ""

    direction = player.position - enemy.position
    if direction.length() > 0:
        enemy.position += direction.normalized() * enemy_speed * time.dt
        enemy.look_at(player.position)

    if distance(player.position, enemy.position) < 35:
        status_text.text = f"CAUGHT!\nSCORE: {int(score)}"
        status_text.enabled = True
        player.speed = 0
        game_over = True
        return

    time_remaining = max(0, time_remaining - time.dt)
    timer_text.text = f"TIME TO ESCAPE: {ceil(time_remaining)}"
    if time_remaining == 0:
        status_text.text = f"YOU ESCAPED!\nFINAL SCORE: {int(score)}"
        status_text.enabled = True
        game_over = True



plane = Entity(
    parent=player,
    model="f14.glb",
    scale = 0.6,
    position=(0,5,0),
    # color = color.gray
)

camera.position = (0, 10, -20)
camera.rotate_x=90
camera.look_at(player)
plane.rotation_x=180
plane.rotation_z = 180

DirectionalLight().look_at(Vec3(1, -1, -1))

app.run()
